-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2020 at 06:02 AM
-- Server version: 5.7.17
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gateau`
--
CREATE DATABASE IF NOT EXISTS `gateau` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `gateau`;

-- --------------------------------------------------------

--
-- Table structure for table `gateau`
--

CREATE TABLE `gateau` (
  `id` int(11) NOT NULL,
  `gateauName` varchar(100) COLLATE utf8_bin NOT NULL,
  `gateauRecipes` text COLLATE utf8_bin NOT NULL,
  `gateauImage` varchar(100) COLLATE utf8_bin NOT NULL,
  `gateauCategory` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `gateau`
--

INSERT INTO `gateau` (`id`, `gateauName`, `gateauRecipes`, `gateauImage`, `gateauCategory`) VALUES
(16, 'GG1', 'sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod', 'g3.jpg', 5),
(17, 'gg2', 'Privacy Policy\r\nValve respects the privacy of its online visitors and customers of its products and services and complies with applicable laws for the protection of your privacy, including, without limitation, the California Consumer Privacy Act (\"CCPA\"), the European Union General Data Protection Regulation (\"GDPR\"), and the Swiss and EU Privacy Shield Frameworks.\r\n\r\n1. Definitions\r\n\r\nWherever we talk about Personal Data below, we mean any information that can either itself identify you as an individual (\"Personally Identifying Information\") or that can be connected to you indirectly by linking it to Personally Identifying Information. Valve also processes anonymous data, aggregated or not, to analyze and produce statistics related to the habits, usage patterns, and demographics of customers as a group or as individuals. Such anonymous data does not allow the identification of the customers to which it relates. Valve may share anonymous data, aggregated or not, with third parties.\r\n\r\nOther capitalized terms in this Privacy Policy shall have the meanings defined in the Steam Subscriber Agreement (\"SSA\").\r\n\r\n2. Why Valve Collects and Processes Data\r\n\r\nValve collects and processes Personal Data for the following reasons:\r\n\r\na) where it is necessary for the performance of our agreement with you to provide a full-featured gaming service and deliver associated Content and Services;\r\nb) where it is necessary for compliance with legal obligations that we are subject to (e.g. our obligations to keep certain information under tax laws);\r\nc) where it is necessary for the purposes of the legitimate and legal interests of Valve or a third party (e.g. the interests of our other customers), except where such interests are overridden by your prevailing legitimate interests and rights; or\r\nd) where you have given consent to it.\r\n\r\nThese reasons for collecting and processing Personal Data determine and limit what Personal Data we collect and how we use it (section 3. below), how long we store it (section 4. below), who has access to it (section 5. below) and what rights and other control mechanisms are available to you as a user (section 6. below).\r\n\r\n3. The Types and Sources of Data We Collect\r\n\r\n3.1 Basic Account Data\r\nWhen setting up an Account, Valve will collect your email address and country of residence. You are also required to choose a user name and a password. The provision of this information is necessary to register a Steam User Account. During setup of your account, the account is automatically assigned a number (the \"Steam ID\") that is later used to reference your user account without directly exposing Personally Identifying Information about you.\r\nWe do not require you to provide or use your real name for the setup of a Steam User Account.\r\n\r\n3.2 Transaction and Payment Data\r\nIn order to make a transaction on Steam (e.g. to purchase Subscriptions for Content and Services or to fund your Steam Wallet), you may need to provide payment data to Valve to enable the transaction. If you pay by credit card, you need to provide typical credit card information (name, address, credit card number, expiration date and security code) to Valve, which Valve will process and transmit to the payment service provider of your choice to enable the transaction and perform anti-fraud checks. Likewise, Valve will receive data from your payment service provider for the same reasons.\r\n\r\n3.3 Other Data You Explicitly Submit\r\nWe will collect and process Personal Data whenever you explicitly provide it to us or send it as part of communication with others on Steam, e.g. in Steam Community Forums, chats, or when you provide feedback or other user generated content. This data includes:\r\nInformation that you post, comment or follow in any of our Content and Services;\r\nInformation sent through chat;\r\nInformation you provide when you request information or support from us or purchase Content and Services from us, including information necessary to process your orders with the relevant payment merchant or, in case of physical goods, shipping providers;\r\nInformation you provide to us when participating in competitions, contests and tournaments or responding to surveys, e.g. your contact details.\r\n3.4 Your Use of the Steam Client and Websites\r\nWe collect a variety of information through your general interaction with the websites, Content and Services offered by Steam. Personal Data we collect may include, but is not limited to, browser and device information, data collected through automated electronic interactions and application usage data.\r\nLikewise, we will track your process across our websites and applications to verify that you are not a bot and to optimize our services.\r\n\r\n3.5 Your Use of Games and other Subscriptions\r\nIn order to provide you with services, we need to collect, store and use various information about your activity in our Content and Services. \"Content-Related Information\" includes your Steam ID, as well as what is usually referred to as \"game statistics\". By game statistics we mean information about your games\' preferences, progress in the games, playtime, as well as information about the device you are using, including what operating system you are using, device settings, unique device identifiers, and crash data.\r\n\r\n3.6 Tracking Data and Cookies\r\nWe use \"Cookies\", which are text files placed on your computer, and similar technologies (e.g. web beacons, pixels, ad tags and device identifiers) to help us analyze how users use our services, as well as to improve the services we are offering, to improve marketing, analytics or website functionality. The use of Cookies is standard on the internet. Although most web browsers automatically accept cookies, the decision of whether to accept or not is yours. You may adjust your browser settings to prevent the reception of cookies, or to provide notification whenever a cookie is sent to you. You may refuse the use of cookies by selecting the appropriate settings on your browser. The management of the use of cookies for each browser is further detailed on the following help page: https://support.steampowered.com/kb_article.php?ref=9076-QYOJ-0930. However, please note that if you do this, you may not be able to access the full functionality of our websites.\r\nWhen you visit any of our services, our servers log your IP address, which is a number that is automatically assigned to the network your computer is part of.\r\n\r\n3.7 Content Recommendations\r\nWe may process information collected under this section 3 so that content, products and services shown on the pages of the Steam store and in update messages displayed when launching the Steam Client can be tailored to meet your needs and populated with relevant recommendations and offers. This is done to improve your customer experience. You can prevent the processing of your data in this way by turning off the automatic loading of the Steam store page and of Steam notifications in the \"Interface\" section of the Steam Client settings.\r\nSubject to your separate consent or where explicitly permitted under applicable laws on email marketing, Valve may send you marketing messages about products and services offered by Valve to your email address. In such a case we may also use your collected information to customize such marketing messages as well as collect information on whether you opened such messages and which links in their text you followed.\r\nYou can opt out or withdraw your consent to receive marketing emails at any time by either withdrawing the consent on the same page where you previously provided it or clicking the \"unsubscribe\" link provided in every marketing email.\r\n\r\n3.8 Information Required to Detect Violations\r\nWe collect certain data that is required for our detection, investigation and prevention of fraud, cheating and other violations of the SSA and applicable laws (\"Violations\"). This data is used only for the purposes of detection, investigation, prevention and, where applicable, acting on of such Violations and stored only for the minimum amount of time needed for this purpose. If the data indicates that a Violation has occurred, we will further store the data for the establishment, exercise or defense of legal claims during the applicable statute of limitations or until a legal case related to it has been resolved. Please note that the specific data stored for this purpose may not be disclosed to you if the disclosure will compromise the mechanism through which we detect, investigate and prevent such Violations.\r\n', 'g2.jpg', 6),
(18, 'ggg3', 'sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod', 'g8.jpg', 5),
(19, 'zzzzzzzzzzzzzzzzz eeeeeeeeeeeeeee', 'sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod', 'g7.jpg', 6),
(20, 'ee354', 'sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, /n eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod', 'g6.jpg', 6),
(24, 'azeazeaze55555', '\r\n\r\n\r\nsed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod', 'g4.jpg', 6),
(22, 'eeeeeeeeeeeeeeeeeeeee', 'sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod', 'g5.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `gateaucategory`
--

CREATE TABLE `gateaucategory` (
  `id` int(11) NOT NULL,
  `Category` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `gateaucategory`
--

INSERT INTO `gateaucategory` (`id`, `Category`) VALUES
(5, 'cat1'),
(6, 'cat2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gateau`
--
ALTER TABLE `gateau`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gateauCategory` (`gateauCategory`);

--
-- Indexes for table `gateaucategory`
--
ALTER TABLE `gateaucategory`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gateau`
--
ALTER TABLE `gateau`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `gateaucategory`
--
ALTER TABLE `gateaucategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;